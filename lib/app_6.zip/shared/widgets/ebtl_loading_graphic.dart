// lib/shared/widgets/ebtl_loading_graphic.dart

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class EbtlLoadingGraphic extends StatelessWidget {
  const EbtlLoadingGraphic({
    super.key,
    this.size = 96,
    this.label = 'Mixing things up...',
    this.showLabel = true,
  });

  final double size;
  final String label;
  final bool showLabel;

  static const Color _navy = Color(0xFF0E2238);
  static const Color _coral = Color(0xFFF35F4B);
  static const Color _cream = Color(0xFFFFF8EE);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _cream,
      alignment: Alignment.center,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            'assets/animations/ebtl_loader.gif',
            width: size,
            height: size,
            fit: BoxFit.contain,
            gaplessPlayback: true,
            filterQuality: FilterQuality.high,
          ),
          if (showLabel) ...[
            const SizedBox(height: 14),
            Text(
              label,
              textAlign: TextAlign.center,
              style: GoogleFonts.manrope(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: _navy,
              ),
            ),
            const SizedBox(height: 4),
            Container(
              width: 28,
              height: 3,
              decoration: BoxDecoration(
                color: _coral,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
          ],
        ],
      ),
    );
  }
}